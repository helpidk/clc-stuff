import math
import os

# instructions down here

def calc():
    history = []

    print("Welcome to the Scientific Calculator!")
    print("Type 'quit' to exit.")
    print("Everything supported in the 'math' module is supported. All functions are listed here: https://docs.python.org/3/library/math.html.")
    print("Note: Use radians for trigonometric functions (e.g., sin(1.57) for sin(90°)).\n")

    while True:
        user_input = input(">>> ")

        if user_input.lower() == "quit":
            print("goodbye!")
            break

        if user_input.lower() == "history":
            if not history:
                print("No calculations in history.")
            else:
                print("Calculation History:")
                for i, (expression, result) in enumerate(history, 1):
                    print(f"{i}: {expression} = {result}")
            continue

        if user_input.lower() == "clear":
            # Clear the screen
            os.system('cls' if os.name == 'nt' else 'clear')
            print("Screen cleared! Continue your calculations.\n")
            continue

# this part below does the actual math
        try:
            result = eval(user_input, {"__builtins__": None}, vars(math))
            print("Result:", result)
            history.append((user_input, result))
        except Exception:
            print("number required")

if __name__ == "__main__":
    calc()
    
    




    